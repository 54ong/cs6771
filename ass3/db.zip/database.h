#ifndef DATABASE_H
#define DATABASE_H

// Your database class definition goes here


#include "database.tem"

#endif
